fake backup for LeakDeny fixture — no real data
